# Wavely — музыкальный плеер с офлайн-режимом

Android-приложение (Kotlin + Jetpack Compose) с бесплатной легальной музыкой.

## Возможности
- Каталог и поиск музыки Jamendo (лицензии Creative Commons)
- Фоновое воспроизведение, уведомление, экран блокировки (Media3)
- Библиотека, плейлисты
- Скачивание треков для офлайн (только если лицензия разрешает)
- Импорт своих аудиофайлов с телефона

## Запуск
1. Установите Android Studio (Koala или новее).
2. Получите бесплатный `client_id` в Jamendo Developers (api.jamendo.com / портал разработчиков).
3. В корне проекта создайте/дополните файл `local.properties`:
   ```
   JAMENDO_CLIENT_ID=ваш_client_id
   ```
   (строка `sdk.dir=...` Android Studio добавит сама)
4. File → Open → папка проекта, дождитесь Gradle Sync, нажмите Run.

Минимальная версия Android: 8.0 (API 26).

## Структура
- `data/` — Room (треки, плейлисты), Retrofit-клиент Jamendo, `MusicRepository`
- `playback/` — `PlaybackService` (ExoPlayer + MediaSession) и `PlayerController`
- `ui/` — экраны Compose: Главная, Поиск, Библиотека, Плейлист, Плеер
