package com.example.wavely.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.wavely.MainViewModel
import com.example.wavely.data.Playlist

@Composable
fun HomeScreen(vm: MainViewModel) {
    val state by vm.popular.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Популярное", "Бесплатная музыка Jamendo (лицензии Creative Commons)")
        ListStateContent(state, vm, emptyText = "Ничего не найдено", onRetry = vm::loadPopular)
    }
}

@Composable
fun SearchScreen(vm: MainViewModel) {
    val state by vm.search.collectAsStateWithLifecycle()
    var text by rememberSaveable { mutableStateOf(vm.query.value) }
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Поиск")
        OutlinedTextField(
            value = text,
            onValueChange = { text = it; vm.setQuery(it) },
            singleLine = true,
            placeholder = { Text("Треки, исполнители, жанры") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (text.isNotEmpty()) {
                    IconButton(onClick = { text = ""; vm.setQuery("") }) {
                        Icon(Icons.Filled.Close, contentDescription = "Очистить")
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )
        if (text.isBlank()) {
            Centered { Text("Введите запрос, чтобы найти музыку") }
        } else {
            ListStateContent(state, vm, emptyText = "Ничего не найдено")
        }
    }
}

@Composable
fun LibraryScreen(vm: MainViewModel, onOpenPlaylist: (Long) -> Unit) {
    val library by vm.library.collectAsStateWithLifecycle()
    val offline by vm.offline.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showCreate by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Playlist?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importLocal(uris)
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 16.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Библиотека", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                Icon(Icons.Filled.Add, contentDescription = "Импорт аудиофайлов с устройства")
            }
        }
        TabRow(selectedTabIndex = tab) {
            listOf("Треки", "Офлайн", "Плейлисты").forEachIndexed { i, title ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) })
            }
        }
        when (tab) {
            0 -> if (library.isEmpty()) {
                Centered {
                    Text("Библиотека пуста. Добавляйте треки через поиск или импортируйте файлы кнопкой «+».")
                }
            } else {
                TrackList(library, vm)
            }
            1 -> if (offline.isEmpty()) {
                Centered { Text("Здесь будут скачанные и импортированные треки — они играют без интернета.") }
            } else {
                TrackList(offline, vm)
            }
            else -> LazyColumn(Modifier.fillMaxSize()) {
                item {
                    TextButton(
                        onClick = { showCreate = true },
                        modifier = Modifier.padding(horizontal = 8.dp),
                    ) { Text("+ Новый плейлист") }
                }
                items(playlists, key = { it.id }) { p ->
                    ListItem(
                        headlineContent = { Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        leadingContent = { Icon(Icons.AutoMirrored.Filled.QueueMusic, contentDescription = null) },
                        trailingContent = {
                            IconButton(onClick = { deleteTarget = p }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Удалить плейлист")
                            }
                        },
                        modifier = Modifier.clickable { onOpenPlaylist(p.id) },
                    )
                }
            }
        }
    }

    if (showCreate) {
        NameDialog(
            title = "Новый плейлист",
            onConfirm = { vm.createPlaylist(it); showCreate = false },
            onDismiss = { showCreate = false },
        )
    }
    deleteTarget?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Удалить плейлист?") },
            text = { Text("«${p.name}» будет удалён. Сами треки останутся в библиотеке.") },
            confirmButton = {
                TextButton(onClick = { vm.deletePlaylist(p.id); deleteTarget = null }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Отмена") } },
        )
    }
}

@Composable
fun PlaylistScreen(id: Long, vm: MainViewModel, onBack: () -> Unit) {
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val name = playlists.firstOrNull { it.id == id }?.name.orEmpty()
    val tracks by remember(id) { vm.playlistTracks(id) }
        .collectAsStateWithLifecycle(initialValue = emptyList())

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
            }
            Text(
                name,
                style = MaterialTheme.typography.titleLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            FilledTonalButton(onClick = { vm.play(tracks, 0) }, enabled = tracks.isNotEmpty()) {
                Text("Слушать")
            }
        }
        if (tracks.isEmpty()) {
            Centered { Text("Плейлист пуст. Добавьте треки через меню «⋮» у любого трека.") }
        } else {
            TrackList(tracks, vm, playlistId = id)
        }
    }
}
