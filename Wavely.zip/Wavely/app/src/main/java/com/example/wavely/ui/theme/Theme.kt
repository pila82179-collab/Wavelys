package com.example.wavely.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkScheme = darkColorScheme(
    primary = Color(0xFFA48DFF),
    onPrimary = Color(0xFF1A0E5C),
    primaryContainer = Color(0xFF3A2C8F),
    onPrimaryContainer = Color(0xFFE6DFFF),
    background = Color(0xFF0E0E12),
    onBackground = Color(0xFFECE9F7),
    surface = Color(0xFF0E0E12),
    onSurface = Color(0xFFECE9F7),
    surfaceVariant = Color(0xFF25232F),
    onSurfaceVariant = Color(0xFFB9B5C9),
)

@Composable
fun WavelyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}
