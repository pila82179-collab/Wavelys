package com.example.wavely.data

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Query

interface JamendoApi {
    @GET("tracks/")
    suspend fun tracks(
        @Query("client_id") clientId: String,
        @Query("format") format: String = "json",
        @Query("limit") limit: Int = 40,
        @Query("search") search: String? = null,
        @Query("order") order: String? = null,
        @Query("imagesize") imageSize: Int = 300,
        @Query("audioformat") audioFormat: String = "mp32",
    ): JamendoResponse
}

data class JamendoResponse(
    val headers: JamendoHeaders? = null,
    val results: List<JamendoTrack>? = null,
)

data class JamendoHeaders(
    val status: String? = null,
    @SerializedName("error_message") val errorMessage: String? = null,
)

data class JamendoTrack(
    val id: String? = null,
    val name: String? = null,
    val duration: Int? = null,
    @SerializedName("artist_name") val artistName: String? = null,
    @SerializedName("album_name") val albumName: String? = null,
    val image: String? = null,
    val audio: String? = null,
    val audiodownload: String? = null,
    @SerializedName("audiodownload_allowed") val audiodownloadAllowed: Boolean? = null,
    @SerializedName("license_ccurl") val licenseUrl: String? = null,
)
