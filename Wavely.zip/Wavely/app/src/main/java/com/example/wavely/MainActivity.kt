package com.example.wavely

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.example.wavely.ui.WavelyRoot
import com.example.wavely.ui.theme.WavelyTheme

class MainActivity : ComponentActivity() {

    private val container get() = (application as WavelyApplication).container

    private val vm: MainViewModel by viewModels { MainViewModelFactory(container) }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* без разрешения плеер всё равно работает */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        container.player.connect()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            WavelyTheme { WavelyRoot(vm) }
        }
    }

    override fun onDestroy() {
        // При повороте экрана контроллер сохраняем, при закрытии — отпускаем (музыка продолжит играть в службе).
        if (isFinishing) container.player.release()
        super.onDestroy()
    }
}
