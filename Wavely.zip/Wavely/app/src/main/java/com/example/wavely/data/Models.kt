package com.example.wavely.data

import android.net.Uri
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.io.File

@Entity(tableName = "tracks")
data class Track(
    @PrimaryKey val id: String,           // "jamendo:123" или "local:<uri>"
    val title: String,
    val artist: String,
    val album: String = "",
    val artworkUrl: String? = null,
    val durationSec: Int = 0,
    val streamUrl: String? = null,        // ссылка для потокового воспроизведения
    val downloadUrl: String? = null,      // не null только если лицензия разрешает скачивание
    val localPath: String? = null,        // путь к скачанному файлу или content://-URI импортированного
    val isLocalImport: Boolean = false,
    val license: String? = null,
    val addedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "playlists")
data class Playlist(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
)

@Entity(
    tableName = "playlist_entries",
    primaryKeys = ["playlistId", "trackId"],
    foreignKeys = [
        ForeignKey(
            entity = Playlist::class,
            parentColumns = ["id"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE,
        ),
        ForeignKey(
            entity = Track::class,
            parentColumns = ["id"],
            childColumns = ["trackId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("trackId")],
)
data class PlaylistEntry(
    val playlistId: Long,
    val trackId: String,
    val position: Long = System.currentTimeMillis(),
)

/** Трек доступен без интернета (скачан или импортирован с устройства). */
val Track.isOffline: Boolean get() = localPath != null

/** Трек скачан из интернета в память приложения. */
val Track.isDownloaded: Boolean get() = !isLocalImport && localPath != null

val Track.canDownload: Boolean get() = !isLocalImport && !downloadUrl.isNullOrBlank()

/** Откуда играть: локальный файл, если он есть, иначе поток. */
fun Track.playbackUri(): Uri? {
    val path = localPath
    return when {
        isLocalImport -> path?.let { Uri.parse(it) }
        path != null && File(path).exists() -> Uri.fromFile(File(path))
        else -> streamUrl?.let { Uri.parse(it) }
    }
}
