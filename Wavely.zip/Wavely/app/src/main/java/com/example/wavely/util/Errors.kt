package com.example.wavely.util

import retrofit2.HttpException
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.Locale

fun errorText(t: Throwable): String = when (t) {
    is UnknownHostException, is ConnectException, is SocketTimeoutException ->
        "Нет подключения к интернету"
    is HttpException -> "Ошибка сервера (${t.code()})"
    is IOException -> "Ошибка сети"
    else -> t.message ?: "Неизвестная ошибка"
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return String.format(Locale.ROOT, "%d:%02d", total / 60, total % 60)
}
