package com.example.wavely

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.example.wavely.data.AppDatabase
import com.example.wavely.data.JamendoApi
import com.example.wavely.data.MusicRepository
import com.example.wavely.playback.PlayerController
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/** Простое ручное внедрение зависимостей. */
class AppContainer(context: Context) {
    private val db = Room.databaseBuilder(context, AppDatabase::class.java, "wavely.db").build()

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val api: JamendoApi = Retrofit.Builder()
        .baseUrl("https://api.jamendo.com/v3.0/")
        .client(http)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(JamendoApi::class.java)

    val repo = MusicRepository(context, db, api, http)
    val player = PlayerController(context)
}

class WavelyApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
