package com.example.wavely.data

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.example.wavely.BuildConfig
import com.example.wavely.util.errorText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class MusicRepository(
    context: Context,
    db: AppDatabase,
    private val api: JamendoApi,
    private val http: OkHttpClient,
) {
    private val appContext = context.applicationContext
    private val trackDao = db.trackDao()
    private val playlistDao = db.playlistDao()

    // Скачивания живут в области приложения и не обрываются при смене экрана.
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val active: MutableSet<String> = ConcurrentHashMap.newKeySet()

    val library: Flow<List<Track>> = trackDao.observeAll()
    val playlists: Flow<List<Playlist>> = playlistDao.observePlaylists()

    private val _progress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _progress.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    // ---------- Каталог (Jamendo) ----------

    suspend fun search(query: String): List<Track> = fetch(search = query, order = null)

    suspend fun popular(): List<Track> = fetch(search = null, order = "popularity_week")

    private suspend fun fetch(search: String?, order: String?): List<Track> {
        val clientId = BuildConfig.JAMENDO_CLIENT_ID
        if (clientId.isBlank()) {
            throw IllegalStateException(
                "Не задан JAMENDO_CLIENT_ID. Добавьте его в local.properties (см. README)."
            )
        }
        val response = api.tracks(clientId = clientId, search = search, order = order)
        val headers = response.headers
        if (headers?.status == "failed") {
            throw IllegalStateException(headers.errorMessage ?: "Ошибка Jamendo API")
        }
        return response.results.orEmpty().mapNotNull { it.toTrack() }.distinctBy { it.id }
    }

    private fun JamendoTrack.toTrack(): Track? {
        val tid = id ?: return null
        val stream = audio?.takeIf { it.isNotBlank() }
        val download = if (audiodownloadAllowed == true) audiodownload?.takeIf { it.isNotBlank() } else null
        if (stream == null && download == null) return null
        return Track(
            id = "jamendo:$tid",
            title = name?.takeIf { it.isNotBlank() } ?: "Без названия",
            artist = artistName?.takeIf { it.isNotBlank() } ?: "Неизвестный исполнитель",
            album = albumName.orEmpty(),
            artworkUrl = image?.takeIf { it.isNotBlank() },
            durationSec = duration ?: 0,
            streamUrl = stream ?: download,
            downloadUrl = download,
            license = licenseUrl,
        )
    }

    // ---------- Библиотека ----------

    suspend fun addToLibrary(track: Track) {
        trackDao.insertIgnore(track)
    }

    suspend fun removeFromLibrary(track: Track) = withContext(Dispatchers.IO) {
        val saved = trackDao.get(track.id) ?: track
        if (!saved.isLocalImport) saved.localPath?.let { File(it).delete() }
        trackDao.delete(saved.id)
    }

    suspend fun removeDownload(track: Track) = withContext(Dispatchers.IO) {
        val saved = trackDao.get(track.id) ?: track
        if (!saved.isLocalImport) {
            saved.localPath?.let { File(it).delete() }
            trackDao.setLocalPath(saved.id, null)
        }
    }

    // ---------- Скачивание ----------

    fun startDownload(track: Track) {
        if (!track.canDownload) {
            _messages.tryEmit("Этот трек нельзя скачать (запрещено лицензией)")
            return
        }
        if (!active.add(track.id)) return // уже скачивается
        scope.launch {
            try {
                download(track)
                _messages.tryEmit("Скачано: ${track.title}")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _messages.tryEmit("Не удалось скачать: ${errorText(e)}")
            } finally {
                active.remove(track.id)
                _progress.update { it - track.id }
            }
        }
    }

    private suspend fun download(track: Track) {
        val url = requireNotNull(track.downloadUrl)
        val dir = File(appContext.filesDir, "music").apply { mkdirs() }
        val safeName = track.id.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val target = File(dir, "$safeName.mp3")
        val temp = File(dir, "$safeName.part")
        _progress.update { it + (track.id to 0f) }
        try {
            http.newCall(Request.Builder().url(url).build()).execute().use { response ->
                if (!response.isSuccessful) throw java.io.IOException("HTTP ${response.code}")
                val body = response.body ?: throw java.io.IOException("Пустой ответ")
                val total = body.contentLength()
                body.byteStream().use { input ->
                    temp.outputStream().use { output ->
                        val buffer = ByteArray(16 * 1024)
                        var done = 0L
                        var lastReported = 0f
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            output.write(buffer, 0, n)
                            done += n
                            if (total > 0) {
                                val p = done.toFloat() / total
                                if (p - lastReported >= 0.01f) {
                                    lastReported = p
                                    _progress.update { it + (track.id to p) }
                                }
                            }
                        }
                    }
                }
            }
            if (target.exists()) target.delete()
            if (!temp.renameTo(target)) {
                temp.copyTo(target, overwrite = true)
                temp.delete()
            }
            trackDao.insertIgnore(track)
            trackDao.setLocalPath(track.id, target.absolutePath)
        } catch (e: Exception) {
            temp.delete()
            throw e
        }
    }

    // ---------- Импорт файлов с устройства ----------

    suspend fun importLocal(uris: List<Uri>) = withContext(Dispatchers.IO) {
        var added = 0
        for (uri in uris) {
            try {
                appContext.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Не все провайдеры дают постоянный доступ — трек всё равно попробуем добавить.
            }
            var title: String? = null
            var artist: String? = null
            var album: String? = null
            var durationMs = 0L
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(appContext, uri)
                title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                    ?: retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST)
                album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L
            } catch (_: Exception) {
                // Нет метаданных — используем имя файла.
            } finally {
                retriever.release()
            }
            val track = Track(
                id = "local:$uri",
                title = title?.takeIf { it.isNotBlank() } ?: displayName(uri) ?: "Без названия",
                artist = artist?.takeIf { it.isNotBlank() } ?: "Неизвестный исполнитель",
                album = album.orEmpty(),
                durationSec = (durationMs / 1000).toInt(),
                localPath = uri.toString(),
                isLocalImport = true,
            )
            if (trackDao.insertIgnore(track) >= 0) added++
        }
        _messages.tryEmit(if (added > 0) "Добавлено треков: $added" else "Новых треков не добавлено")
    }

    private fun displayName(uri: Uri): String? =
        appContext.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            ?.substringBeforeLast('.')

    // ---------- Плейлисты ----------

    suspend fun createPlaylist(name: String): Long = playlistDao.insertPlaylist(Playlist(name = name))

    suspend fun deletePlaylist(id: Long) = playlistDao.deletePlaylist(id)

    suspend fun addToPlaylist(playlistId: Long, track: Track) {
        trackDao.insertIgnore(track) // трек должен существовать в БД (внешний ключ)
        playlistDao.addEntry(PlaylistEntry(playlistId, track.id))
    }

    suspend fun removeFromPlaylist(playlistId: Long, trackId: String) =
        playlistDao.removeEntry(playlistId, trackId)

    fun playlistTracks(playlistId: Long): Flow<List<Track>> = playlistDao.observeTracks(playlistId)
}
