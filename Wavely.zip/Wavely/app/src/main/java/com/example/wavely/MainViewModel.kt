package com.example.wavely

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.wavely.data.Playlist
import com.example.wavely.data.Track
import com.example.wavely.data.isOffline
import com.example.wavely.util.errorText
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ListState(
    val loading: Boolean = false,
    val items: List<Track> = emptyList(),
    val error: String? = null,
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class MainViewModel(container: AppContainer) : ViewModel() {

    private val repo = container.repo
    val player = container.player
    val playerState = player.state

    /** Сообщения для Snackbar (ошибки, статусы скачивания). */
    val messages: Flow<String> = merge(repo.messages, player.errors)

    // ----- Библиотека -----
    val library: StateFlow<List<Track>> =
        repo.library.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val offline: StateFlow<List<Track>> =
        library.map { list -> list.filter { it.isOffline } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val libraryIds: StateFlow<Set<String>> =
        library.map { list -> list.map { it.id }.toSet() }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val playlists: StateFlow<List<Playlist>> =
        repo.playlists.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val downloadProgress: StateFlow<Map<String, Float>> = repo.downloadProgress

    /** Подмешиваем версии треков из БД, чтобы в каталоге были видны скачанные и добавленные. */
    private fun Flow<ListState>.mergeLibrary(): Flow<ListState> =
        combine(this, library) { state, lib ->
            val byId = lib.associateBy { it.id }
            state.copy(items = state.items.map { byId[it.id] ?: it })
        }

    private suspend fun load(block: suspend () -> List<Track>): ListState =
        try {
            ListState(items = block())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ListState(error = errorText(e))
        }

    // ----- Главная -----
    private val popularRaw = MutableStateFlow(ListState(loading = true))
    val popular: StateFlow<ListState> = popularRaw
        .mergeLibrary()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ListState(loading = true))

    fun loadPopular() {
        viewModelScope.launch {
            popularRaw.value = ListState(loading = true)
            popularRaw.value = load { repo.popular() }
        }
    }

    // ----- Поиск -----
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()
    fun setQuery(value: String) {
        _query.value = value
    }

    val search: StateFlow<ListState> = _query
        .debounce(400)
        .map { it.trim() }
        .distinctUntilChanged()
        .flatMapLatest { q ->
            if (q.isEmpty()) {
                flowOf(ListState())
            } else {
                flow {
                    emit(ListState(loading = true))
                    emit(load { repo.search(q) })
                }
            }
        }
        .mergeLibrary()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ListState())

    init {
        loadPopular()
    }

    // ----- Действия -----
    fun play(tracks: List<Track>, index: Int) = player.playTracks(tracks, index)

    fun toggleLibrary(track: Track) {
        viewModelScope.launch {
            if (track.id in libraryIds.value) repo.removeFromLibrary(track) else repo.addToLibrary(track)
        }
    }

    fun download(track: Track) = repo.startDownload(track)

    fun removeDownload(track: Track) {
        viewModelScope.launch { repo.removeDownload(track) }
    }

    fun importLocal(uris: List<android.net.Uri>) {
        viewModelScope.launch { repo.importLocal(uris) }
    }

    fun createPlaylist(name: String) {
        viewModelScope.launch { repo.createPlaylist(name) }
    }

    fun createPlaylistAndAdd(name: String, track: Track) {
        viewModelScope.launch {
            val id = repo.createPlaylist(name)
            repo.addToPlaylist(id, track)
        }
    }

    fun deletePlaylist(id: Long) {
        viewModelScope.launch { repo.deletePlaylist(id) }
    }

    fun addToPlaylist(playlistId: Long, track: Track) {
        viewModelScope.launch { repo.addToPlaylist(playlistId, track) }
    }

    fun removeFromPlaylist(playlistId: Long, track: Track) {
        viewModelScope.launch { repo.removeFromPlaylist(playlistId, track.id) }
    }

    fun playlistTracks(id: Long): Flow<List<Track>> = repo.playlistTracks(id)
}

class MainViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(container) as T
}
