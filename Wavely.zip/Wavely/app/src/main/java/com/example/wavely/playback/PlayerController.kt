package com.example.wavely.playback

import android.content.ComponentName
import android.content.Context
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.wavely.data.Track
import com.example.wavely.data.playbackUri
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

data class PlayerUiState(
    val hasMedia: Boolean = false,
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val artworkUri: String? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
)

/** Обёртка над MediaController: UI общается с PlaybackService через неё. */
class PlayerController(context: Context) {

    private val appContext = context.applicationContext
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private val _errors = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val errors: SharedFlow<String> = _errors.asSharedFlow()

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync()
        }

        override fun onPlayerError(error: PlaybackException) {
            _errors.tryEmit("Не удалось воспроизвести трек. Проверьте интернет или скачайте его.")
        }
    }

    fun connect() {
        if (future != null) return
        val token = SessionToken(appContext, ComponentName(appContext, PlaybackService::class.java))
        val f = MediaController.Builder(appContext, token).buildAsync()
        future = f
        f.addListener(
            {
                try {
                    val c = f.get()
                    c.addListener(listener)
                    controller = c
                    sync()
                } catch (e: Exception) {
                    future = null
                    controller = null
                }
            },
            ContextCompat.getMainExecutor(appContext),
        )
    }

    fun release() {
        controller?.removeListener(listener)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
    }

    private fun sync() {
        val c = controller ?: return
        val item = c.currentMediaItem
        val md = c.mediaMetadata
        val duration = c.duration
        _state.value = PlayerUiState(
            hasMedia = item != null,
            mediaId = item?.mediaId,
            title = md.title?.toString().orEmpty(),
            artist = md.artist?.toString().orEmpty(),
            artworkUri = md.artworkUri?.toString(),
            isPlaying = c.isPlaying,
            durationMs = if (duration >= 0) duration else 0L,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
        )
    }

    fun playTracks(tracks: List<Track>, startIndex: Int) {
        val c = controller
        if (c == null) {
            _errors.tryEmit("Плеер запускается, попробуйте ещё раз")
            return
        }
        val start = tracks.getOrNull(startIndex) ?: return
        val playable = tracks.mapNotNull { t -> t.toMediaItem()?.let { t to it } }
        val index = playable.indexOfFirst { it.first.id == start.id }
        if (index < 0) {
            _errors.tryEmit("Этот трек недоступен для воспроизведения")
            return
        }
        c.setMediaItems(playable.map { it.second }, index, 0L)
        c.prepare()
        c.play()
    }

    private fun Track.toMediaItem(): MediaItem? {
        val uri = playbackUri() ?: return null
        val metadata = MediaMetadata.Builder()
            .setTitle(title)
            .setArtist(artist)
            .setAlbumTitle(album.ifBlank { null })
            .setArtworkUri(artworkUrl?.let { android.net.Uri.parse(it) })
            .build()
        return MediaItem.Builder()
            .setMediaId(id)
            .setUri(uri)
            .setMediaMetadata(metadata)
            .build()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
    }

    fun position(): Long = controller?.currentPosition ?: 0L

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    fun cycleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
}
