package com.example.wavely.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.wavely.MainViewModel

private object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val LIBRARY = "library"
    const val PLAYLIST = "playlist"
    const val PLAYER = "player"
}

private data class TabItem(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem(Routes.HOME, "Главная", Icons.Filled.Home),
    TabItem(Routes.SEARCH, "Поиск", Icons.Filled.Search),
    TabItem(Routes.LIBRARY, "Библиотека", Icons.Filled.LibraryMusic),
)

@Composable
fun WavelyRoot(vm: MainViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val snackbar = remember { SnackbarHostState() }
    val playerState by vm.playerState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        vm.messages.collect { snackbar.showSnackbar(it) }
    }

    val selectedRoute = if (route?.startsWith(Routes.PLAYLIST) == true) Routes.LIBRARY else route

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (route != Routes.PLAYER) {
                Column {
                    if (playerState.hasMedia) {
                        MiniPlayer(
                            state = playerState,
                            onToggle = vm.player::togglePlay,
                            onNext = vm.player::next,
                            onClick = { nav.navigate(Routes.PLAYER) { launchSingleTop = true } },
                        )
                    }
                    NavigationBar {
                        tabs.forEach { tab ->
                            NavigationBarItem(
                                selected = selectedRoute == tab.route,
                                onClick = {
                                    nav.navigate(tab.route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(tab.icon, contentDescription = null) },
                                label = { Text(tab.label) },
                            )
                        }
                    }
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = Routes.HOME, modifier = Modifier.padding(padding)) {
            composable(Routes.HOME) { HomeScreen(vm) }
            composable(Routes.SEARCH) { SearchScreen(vm) }
            composable(Routes.LIBRARY) {
                LibraryScreen(vm, onOpenPlaylist = { id -> nav.navigate("${Routes.PLAYLIST}/$id") })
            }
            composable(
                route = "${Routes.PLAYLIST}/{id}",
                arguments = listOf(navArgument("id") { type = NavType.LongType }),
            ) { entry ->
                PlaylistScreen(
                    id = entry.arguments?.getLong("id") ?: 0L,
                    vm = vm,
                    onBack = { nav.popBackStack() },
                )
            }
            composable(Routes.PLAYER) {
                NowPlayingScreen(vm, onBack = { nav.popBackStack() })
            }
        }
    }
}
