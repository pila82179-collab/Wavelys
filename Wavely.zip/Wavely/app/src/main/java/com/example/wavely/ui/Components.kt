package com.example.wavely.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material.icons.filled.LibraryAddCheck
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.wavely.ListState
import com.example.wavely.MainViewModel
import com.example.wavely.data.Playlist
import com.example.wavely.data.Track
import com.example.wavely.data.canDownload
import com.example.wavely.data.isDownloaded
import com.example.wavely.util.formatTime

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        if (subtitle != null) {
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun Centered(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { content() }
}

@Composable
fun Artwork(url: String?, modifier: Modifier = Modifier, corner: Dp = 8.dp) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(corner))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        if (url != null) {
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(
                Icons.Filled.MusicNote,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** Показывает загрузку / ошибку / пустой список / список треков. */
@Composable
fun ListStateContent(
    state: ListState,
    vm: MainViewModel,
    emptyText: String,
    onRetry: (() -> Unit)? = null,
) {
    val error = state.error
    when {
        state.loading -> Centered { CircularProgressIndicator() }
        error != null -> Centered {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(error, textAlign = TextAlign.Center)
                if (onRetry != null) {
                    Spacer(Modifier.size(12.dp))
                    Button(onClick = onRetry) { Text("Повторить") }
                }
            }
        }
        state.items.isEmpty() -> Centered { Text(emptyText, textAlign = TextAlign.Center) }
        else -> TrackList(state.items, vm)
    }
}

@Composable
fun TrackList(
    tracks: List<Track>,
    vm: MainViewModel,
    modifier: Modifier = Modifier,
    playlistId: Long? = null,
) {
    val libraryIds by vm.libraryIds.collectAsStateWithLifecycle()
    val progress by vm.downloadProgress.collectAsStateWithLifecycle()
    val player by vm.playerState.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    var dialogTrack by remember { mutableStateOf<Track?>(null) }

    LazyColumn(modifier = modifier.fillMaxSize()) {
        itemsIndexed(tracks, key = { _, t -> t.id }) { index, track ->
            TrackRow(
                track = track,
                isCurrent = player.mediaId == track.id,
                inLibrary = track.id in libraryIds,
                progress = progress[track.id],
                inPlaylist = playlistId != null,
                onClick = { vm.play(tracks, index) },
                onToggleLibrary = { vm.toggleLibrary(track) },
                onDownload = { vm.download(track) },
                onRemoveDownload = { vm.removeDownload(track) },
                onAddToPlaylist = { dialogTrack = track },
                onRemoveFromPlaylist = { playlistId?.let { vm.removeFromPlaylist(it, track) } },
            )
        }
    }

    dialogTrack?.let { track ->
        AddToPlaylistDialog(
            playlists = playlists,
            onPick = { vm.addToPlaylist(it.id, track); dialogTrack = null },
            onCreate = { name -> vm.createPlaylistAndAdd(name, track); dialogTrack = null },
            onDismiss = { dialogTrack = null },
        )
    }
}

@Composable
private fun TrackRow(
    track: Track,
    isCurrent: Boolean,
    inLibrary: Boolean,
    progress: Float?,
    inPlaylist: Boolean,
    onClick: () -> Unit,
    onToggleLibrary: () -> Unit,
    onDownload: () -> Unit,
    onRemoveDownload: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRemoveFromPlaylist: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val subtitle = listOf(track.artist, if (track.durationSec > 0) formatTime(track.durationSec * 1000L) else "")
        .filter { it.isNotBlank() }
        .joinToString(" · ")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(track.artworkUrl, Modifier.size(52.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Text(
                subtitle,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (progress != null) {
            CircularProgressIndicator(
                progress = { progress },
                modifier = Modifier.padding(horizontal = 8.dp).size(22.dp),
                strokeWidth = 2.dp,
            )
        } else if (track.isDownloaded) {
            Icon(
                Icons.Filled.DownloadDone,
                contentDescription = "Скачано",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 8.dp).size(20.dp),
            )
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Меню") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                MenuItem(
                    if (inLibrary) "Убрать из библиотеки" else "Добавить в библиотеку",
                    if (inLibrary) Icons.Filled.LibraryAddCheck else Icons.Filled.LibraryAdd,
                ) { menu = false; onToggleLibrary() }
                if (track.isDownloaded) {
                    MenuItem("Удалить загрузку", Icons.Filled.Delete) { menu = false; onRemoveDownload() }
                } else if (track.canDownload && progress == null) {
                    MenuItem("Скачать для офлайн", Icons.Filled.Download) { menu = false; onDownload() }
                }
                MenuItem("Добавить в плейлист", Icons.AutoMirrored.Filled.PlaylistAdd) {
                    menu = false; onAddToPlaylist()
                }
                if (inPlaylist) {
                    MenuItem("Убрать из плейлиста", Icons.Filled.RemoveCircleOutline) {
                        menu = false; onRemoveFromPlaylist()
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuItem(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
) {
    DropdownMenuItem(
        text = { Text(text) },
        leadingIcon = { Icon(icon, contentDescription = null) },
        onClick = onClick,
    )
}

@Composable
fun AddToPlaylistDialog(
    playlists: List<Playlist>,
    onPick: (Playlist) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить в плейлист") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LazyColumn(Modifier.heightIn(max = 220.dp)) {
                    items(playlists, key = { it.id }) { p ->
                        Text(
                            p.name,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(p) }
                                .padding(vertical = 12.dp),
                        )
                    }
                }
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Новый плейлист") },
                    singleLine = true,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(newName.trim()) }, enabled = newName.isNotBlank()) {
                Text("Создать")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
fun NameDialog(title: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Название") },
                singleLine = true,
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(name.trim()) }, enabled = name.isNotBlank()) { Text("Создать") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}
